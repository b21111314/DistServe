Multi Head Attention
====================

.. autoclass:: xformers.components.MultiHeadDispatch
    :members:
    :undoc-members:
